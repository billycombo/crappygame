install:
right click on TerminalHacker.zip
click extract all
then run 2_Terminal_Hacker.exe
controls:
keyboard for typing
type menu to return to menu
type close to close the game
try and find the easter eggs