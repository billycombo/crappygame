how to play horrible game:
1. Extract CrappyGame file
2. run - Tile Maps Example.exe
3. if your computer says its a virus then tell it to phuk off